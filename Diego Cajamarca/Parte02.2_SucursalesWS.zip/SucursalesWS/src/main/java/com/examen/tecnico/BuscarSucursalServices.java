package com.examen.tecnico;

public interface BuscarSucursalServices {

	public BuscarSucursalResponse buscarSucursal(BuscarSucursal input);

}
