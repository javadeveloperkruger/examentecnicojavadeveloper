package ec.app.banco;

import ec.app.banco.jpa.Banco;
import ec.app.banco.model.ModelApiResponse;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class AppProcessor {

	EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("JPABanco");
	EntityManager em = emfactory.createEntityManager();

	public ModelApiResponse getBanco() throws Exception {
		Query query = em.createNamedQuery("Banco.findAll", Banco.class);
		List<Banco> bancos = query.getResultList();
		
		ModelApiResponse apiResponse  = new ModelApiResponse().codigo("200");
		apiResponse.setMensaje("EXITO");
		apiResponse.setBanco(bancos.get(0));
		return apiResponse;
	}

	public ModelApiResponse putBanco() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse deleteBanco() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse postBanco() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse getSucursal() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse putSucursal() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse deleteSucursal() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse postSucursal() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse getOrdenPago() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse postOrdenPago() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse deleteOrdenPago() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

	public ModelApiResponse putOrdenPago() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("EXITO");
	}

}