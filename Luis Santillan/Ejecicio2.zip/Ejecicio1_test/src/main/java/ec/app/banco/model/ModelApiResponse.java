package ec.app.banco.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ModelApiResponse {

	private String codigo = null;

	private String mensaje = null;

	/**
	 * Get codigo
	 * 
	 * @return codigo
	 **/
	@JsonProperty("codigo")
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public ModelApiResponse codigo(String codigo) {
		this.codigo = codigo;
		return this;
	}

	/**
	 * Get mensaje
	 * 
	 * @return mensaje
	 **/
	@JsonProperty("mensaje")
	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public ModelApiResponse mensaje(String mensaje) {
		this.mensaje = mensaje;
		return this;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class ModelApiResponse {\n");

		sb.append("    codigo: ").append(toIndentedString(codigo)).append("\n");
		sb.append("    mensaje: ").append(toIndentedString(mensaje)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private static String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
