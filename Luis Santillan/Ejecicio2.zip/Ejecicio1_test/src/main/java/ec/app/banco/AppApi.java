package ec.app.banco;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.sun.istack.NotNull;

import ec.app.banco.model.Banco;
import ec.app.banco.model.ModelApiResponse;
import ec.app.banco.model.OrdenPago;
import ec.app.banco.model.Sucursal;

@Path("/")
public class AppApi {

	@PUT
	@Path("/banco/{id}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse actualizarBanco(Banco actualizarBanco, @PathParam("id") String id) {
		return null;
	}

	@PUT
	@Path("/ordenPago/{id}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse actualizarOrdenPago(@PathParam("id") String id, OrdenPago actualizarOrdenPago) {
		return null;
	}

	@PUT
	@Path("/sucursal/{id}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse actualizarSucursal(@PathParam("id") String id, Sucursal sucursal) {
		return null;
	}

	@DELETE
	@Path("/banco/{id}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse borrarBanco(@PathParam("id") String id) {
		return null;
	}

	@POST
	@Path("/banco")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse crearBanco(Banco crearBanco) {
		return null;
	}

	@POST
	@Path("/ordenpago")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse crearOrdenPago(OrdenPago crearOrdenPago) {
		return null;
	}

	@POST
	@Path("/sucursal")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse crearSucursal(Sucursal crearSucursal) {
		return null;
	}

	@DELETE
	@Path("/ordenPago/{id}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse eliminarOrdenPago(@QueryParam("id") @NotNull String id, @PathParam("id") String id2) {
		return null;
	}

	@DELETE
	@Path("/sucursal/{id}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse eliminarSucursal(@PathParam("id") String id) {
		return null;
	}

	@GET
	@Path("/sucursal/{id}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse getSucursalId(@PathParam("id") String id) {
		return null;
	}

	@GET
	@Path("/banco")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	public ModelApiResponse listaBancos() {
		return null;
	}
}
