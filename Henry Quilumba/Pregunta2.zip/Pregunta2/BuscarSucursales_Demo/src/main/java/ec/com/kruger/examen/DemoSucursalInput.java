package ec.com.kruger.examen;

public class DemoSucursalInput {

	
	private int  idBanco;

	public int getIdBanco() {
		return idBanco;
	}

	public void setIdBanco(int idBanco) {
		this.idBanco = idBanco;
	}
	

	
}
