package ec.com.kruger.examen;



public interface DemoSucursalServices {
	
	public DemoSucursalOutput buscarSucursal(DemoSucursalInput input);
	

}
