package ec.app.banco.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Banco {

	private String nombre = null;

	private String direccion = null;

	private String fechaRegistro = null;

	/**
	 * Get nombre
	 * 
	 * @return nombre
	 **/
	@JsonProperty("nombre")
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Banco nombre(String nombre) {
		this.nombre = nombre;
		return this;
	}

	/**
	 * Get direccion
	 * 
	 * @return direccion
	 **/
	@JsonProperty("direccion")
	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public Banco direccion(String direccion) {
		this.direccion = direccion;
		return this;
	}

	/**
	 * Get fechaRegistro
	 * 
	 * @return fechaRegistro
	 **/
	@JsonProperty("fechaRegistro")
	public String getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public Banco fechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
		return this;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Banco {\n");

		sb.append("    nombre: ").append(toIndentedString(nombre)).append("\n");
		sb.append("    direccion: ").append(toIndentedString(direccion)).append("\n");
		sb.append("    fechaRegistro: ").append(toIndentedString(fechaRegistro)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private static String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
