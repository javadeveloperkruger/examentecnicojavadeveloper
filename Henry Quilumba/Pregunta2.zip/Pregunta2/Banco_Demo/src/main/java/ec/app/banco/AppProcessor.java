package ec.app.banco;

import ec.app.banco.jpa.Banco;
import ec.app.banco.model.ModelApiResponse;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class AppProcessor {
	
	EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "JPABanco" );
    EntityManager em = emfactory.createEntityManager();
	

	public ModelApiResponse getBanco() throws Exception {
		Query query = em.createNativeQuery("select a from banco a");
		List<Banco> bancos= query.getResultList();
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse putBanco() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse deleteBanco() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse postBanco() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse getSucursal() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse putSucursal() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse deleteSucursal() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse postSucursal() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse getOrdenPago() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse postOrdenPago() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse deleteOrdenPago() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

	public ModelApiResponse putOrdenPago() throws Exception {
		return new ModelApiResponse().codigo("200").mensaje("mensaje");
	}

}