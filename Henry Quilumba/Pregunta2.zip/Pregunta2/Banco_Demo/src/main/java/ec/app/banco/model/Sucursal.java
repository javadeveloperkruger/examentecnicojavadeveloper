package ec.app.banco.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Sucursal {

	private String idBanco = null;

	private String nombre = null;

	private String direccion = null;

	private String fechaRegistro = null;

	/**
	 * Get idBanco
	 * 
	 * @return idBanco
	 **/
	@JsonProperty("idBanco")
	public String getIdBanco() {
		return idBanco;
	}

	public void setIdBanco(String idBanco) {
		this.idBanco = idBanco;
	}

	public Sucursal idBanco(String idBanco) {
		this.idBanco = idBanco;
		return this;
	}

	/**
	 * Get nombre
	 * 
	 * @return nombre
	 **/
	@JsonProperty("nombre")
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Sucursal nombre(String nombre) {
		this.nombre = nombre;
		return this;
	}

	/**
	 * Get direccion
	 * 
	 * @return direccion
	 **/
	@JsonProperty("direccion")
	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public Sucursal direccion(String direccion) {
		this.direccion = direccion;
		return this;
	}

	/**
	 * Get fechaRegistro
	 * 
	 * @return fechaRegistro
	 **/
	@JsonProperty("fechaRegistro")
	public String getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public Sucursal fechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
		return this;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Sucursal {\n");

		sb.append("    idBanco: ").append(toIndentedString(idBanco)).append("\n");
		sb.append("    nombre: ").append(toIndentedString(nombre)).append("\n");
		sb.append("    direccion: ").append(toIndentedString(direccion)).append("\n");
		sb.append("    fechaRegistro: ").append(toIndentedString(fechaRegistro)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private static String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
