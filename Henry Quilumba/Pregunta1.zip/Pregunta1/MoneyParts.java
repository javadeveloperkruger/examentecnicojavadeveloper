package ec.com.kruger.examen;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * @author david
 *
 */
public class MoneyParts {

	private List<Double> combinaciones;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MoneyParts moneyParts = new MoneyParts();
		ArrayList<List<Double>> respuesta = moneyParts.bluid(10.5d);
		System.out.print(respuesta.size());
		System.out.println(respuesta);
	}

	public MoneyParts() {

		// Inicializa las combinaciones
		combinaciones = new ArrayList<Double>();
		combinaciones.add(0.05d);
		combinaciones.add(0.1d);
		combinaciones.add(0.2d);
		combinaciones.add(0.5d);
		combinaciones.add(1d);
		combinaciones.add(2d);
		combinaciones.add(5d);
		combinaciones.add(10d);
		combinaciones.add(20d);
		combinaciones.add(50d);
		combinaciones.add(100d);
		combinaciones.add(200d);
	}

	public ArrayList<List<Double>> bluid(Double entrada) {
		ArrayList<List<Double>> respuesta = new ArrayList<List<Double>>();

		combinaciones.forEach(combinacion -> {
			Double rest = getMod(entrada, combinacion);
			Integer iteraciones = divisionInt(entrada, combinacion);

			if (iteraciones != 0) {
				List<Double> listaCombinacionesNuevas = new ArrayList<Double>();
				for (int i = 0; i < iteraciones; i++) {
					listaCombinacionesNuevas.add(combinacion);
				}
				if (rest.equals(new Double(0))) {
					respuesta.add(listaCombinacionesNuevas);
				}

				else {
	
					if (combinaciones.contains(rest)) {
						listaCombinacionesNuevas.add(rest);
						respuesta.add(listaCombinacionesNuevas);
					} else {

						ArrayList<List<Double>> respuestaResiduo = bluid(rest);
						if (respuestaResiduo.isEmpty()) {
							respuesta.add(listaCombinacionesNuevas);
						} else {
							respuestaResiduo.forEach(listaResiduo -> {
								ArrayList<Double> listaLocal = new ArrayList<Double>();
								listaLocal.addAll(listaCombinacionesNuevas);
								listaLocal.addAll(listaResiduo);
								respuesta.add(listaLocal);
							});
						}
					}
				}
			}
		});

		return respuesta;
	}

	public Double getMod(Double numerator, Double denominator) {
		Integer intPart = divisionInt(numerator, denominator);
		Double rest = numerator - denominator * intPart;

		return roundDouble(rest);
	}


	private double roundDouble(Double rest) {
		return new BigDecimal(rest).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}


	public Integer divisionInt(Double numerator, Double denominator) {
		Integer intPart = ((Double) (numerator / denominator)).intValue();

		return intPart;
	}


	public List<Double> getCombinaciones() {
		return combinaciones;
	}

	public void setCombinaciones(List<Double> combinaciones) {
		this.combinaciones = combinaciones;
	}

}
